$(document).ready(function(){
  $('#tablej tbody tr:even').css('background-color','#F1FA93');
  //alert($('#tablej tr').length + ' elements!');
 // alert($('img').length + ' elements!');
});